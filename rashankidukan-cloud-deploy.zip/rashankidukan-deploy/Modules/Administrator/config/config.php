<?php

return [
    'name' => 'Administrator',
];

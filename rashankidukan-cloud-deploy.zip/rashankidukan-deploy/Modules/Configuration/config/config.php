<?php

return [
    'name' => 'Configuration',
];
